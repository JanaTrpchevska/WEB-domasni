const photos = [
    {
        name: "Notre Dame",
        city: "Paris",
        date: "2026-05-10",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZg33b6hw6YpSKFx9pQnDoLiQaPWXTcRCWGREPdXrizHz1CIGi1EzHOmYD&s=10",
        likes: 25,
        dislikes: 3
    },
    {
        name: "Eiffel Tower",
        city: "Paris",
        date: "2026-08-20",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ8o4GK-vQspVpD_9Fl_7lJIy4v3OgXwDvG1Oo7AvC43VkX6y0uwT-AMWA7&s=10",
        likes: 15,
        dislikes: 3,
    },
    {
        name: "Louvre Museum",
        city: "Paris",
        date: "2026-01-08",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxXlzK2n06kJXYL-bWTux4O_Hjd-WcmdRiLipJScVNKLlkPOqHOtHYRX8&s=10",
        likes: 17,
        dislikes: 5,
    },
    {
        name: "Pantheon",
        city: "Rome",
        date: "2026-06-15",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRuSy3NTcjRNoJeSFLb2P9zOdiSFNbFe2fb9rwvvwRDoxoyUKZrmUBN-oq9&s=10",
        likes: 18,
        dislikes: 2
    },
{
        name: "Rome",
        city: "Rome",
        date: "2026-06-15",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgutcx4Zrr5HvSixyi3NNfzLM6GnfDP_go70Ob8GQIaIyeR-2E2Iffkoc&s=10",
        likes: 68,
        dislikes: 19,
    },
    {
        name: "Rome",
        city: "Rome",
        date: "2026-07-05",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRn3Ibzpp8XaY8cLFKMbgTaUS8QB5T-ChwYkodSAmJJfsz2rFWSRehK4l0&s=10",
        likes: 18,
        dislikes: 2
    },
    {
        name: "Santorini",
        city: "Santorini",
        date: "2026-07-20",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZqMV95xkK5qBnXrUsNKoGt6KRf1_FalQErCyBNK87BuT5SFsptnjcYco&s=10",
        likes: 42,
        dislikes: 5
    },

    {
        name: "Boat Tour",
        city: "New York",
        date: "2026-05-10",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQiU4oeNmvluFnrAwGd-9BXHMT3egGUJEqNKUnKkMl6Eg&s",
        likes: 30,
        dislikes: 4
    },

    {
        name: "Barcelona",
        city: "Barcelona",
        date: "2026-04-23",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzVslxzOS4C4g1ntzD3TfVZBAmsaqP3nqaMZrJ9wpNpA&s=10",
        likes: 35,
        dislikes: 2
    },
    {
        name: "Barcelona",
        city: "Barcelona",
        date: "2026-04-23",
        image: "https://images.euronews.com/articles/stories/08/55/65/48/1536x864_cmsv2_2c47686a-f250-58da-b3f4-c5e45ad8e36e-8556548.jpg",
        likes: 26,
        dislikes: 4
    },

    {
        name: "Tokyo",
        city: "Tokyo",
        date: "2026-02-20",
        image: "https://niewmedia.com/wp-content/uploads/2024/04/a39f2c196779290f50bf69c879ea478f-1280x854.jpg",
        likes: 50,
        dislikes: 6
    },
    {
        name: "Museum Ghibli",
        city: "Tokyo",
        date: "2026-05-14",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPkrp5LZi9Zaba_GCcULYBB04RrW7GN0x4bUmP2v-B8g&s",
        likes: 40,
        dislikes: 3
    },
    {
        name: "Empire State building",
        city: "New York",
        date: "2026-08-16",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFYSqPET4gGv4vDEd65e3hURT7HdaJNnVyBLG4F7araso4FH1FkyeNrnxs&s=10",
        likes: 39,
        dislikes: 1,
    },

    {
        name: "London",
        city: "London",
        date: "2026-05-13",
        image: "https://www.londonphototours.co.uk/wp-content/uploads/2015/03/LPT_large-group-tour2356.jpg",
        likes: 28,
        dislikes: 3
    },

    {
        name: "The Great Pyramid",
        city: "Giza",
        date: "2026-01-18",
        image: "https://www.weroad.it/cdn-cgi/image/q=75,scq=60,f=auto/https://strapi-imaginary.weroad.it/resource/medium/484126/weroad-group-trip-posing-pyramid.jpg",
        likes: 45,
        dislikes: 7,
    },
    {
        name: "The Great Sphinx of Giza",
        city: "Giza",
        date: "2026-03-28",
        image: "https://i.pinimg.com/736x/76/6c/40/766c4056310dce4a708e615e932bcb5a.jpg",
        likes: 35,
        dislikes: 5
    }
];
const gallery = document.getElementById("gallery-container");
photos.forEach(function(photo) {
    const card = document.createElement("div");
    card.className = "col-lg-4 col-md-6 mb-4 photo";
    card.dataset.city = photo.city;
    let userReaction = null;
    card.innerHTML = `
        <div class="gallery-box">
            <h3>${photo.name}</h3>
            <img src="${photo.image}" alt="${photo.name}">
            <p>Location: ${photo.city}</p>
            <p>Date taken: ${photo.date}</p>
            <button class="btn btn-success like"> 👍 <span>${photo.likes}</span> </button>
            <button class="btn btn-danger dislike"> 👎 <span>${photo.dislikes}</span> </button>
            <hr>
            <input type="text" class="form-control comment-input"placeholder="Write a comment...">
            <button class="btn btn-primary comment mt-2">Send</button>
            <div class="comments"></div>
        </div>
    `;
    gallery.appendChild(card);
    const likeButton = card.querySelector(".like");
    const dislikeButton = card.querySelector(".dislike");
    function updateReaction(reaction) 
    {
        if (userReaction === reaction) {
            if (reaction === "like") {
                photo.likes--;
            } else {
                photo.dislikes--;
            }
            userReaction = null;
        } 
        else 
            {
            if (userReaction === "like") {
                photo.likes--;
            } else if (userReaction === "dislike") {
                photo.dislikes--;
            }
            if (reaction === "like") {
                photo.likes++;
            } else {
                photo.dislikes++;
            }
            userReaction = reaction;
        }
        likeButton.querySelector("span").textContent =
            photo.likes;
        dislikeButton.querySelector("span").textContent =
            photo.dislikes;
    }
    likeButton.onclick = function() {
        updateReaction("like");
    };
    dislikeButton.onclick = function() {
        updateReaction("dislike");
    };
    card.querySelector(".comment").onclick = function() {
        let input = card.querySelector(".comment-input");
        let text = input.value.trim();
        if (text !== "") 
            {
            let comment = document.createElement("p");
            comment.textContent = text;
            card.querySelector(".comments").appendChild(comment);
            input.value = "";
        }
    };
}
);
let photoSearch = document.getElementById("photoSearch");
let photoCity = document.getElementById("photoCity");
function filterPhotos() 
{
    let photoCards = document.querySelectorAll(".photo");
    photoCards.forEach(function(photo) {
        let name = photo.textContent.toLowerCase();
        let searchValue = photoSearch.value.toLowerCase();
        let city = photo.dataset.city;
       let matchesSearch = name.includes(searchValue);
            photoCity.value === "" || photoCity.value === city;
        if (matchesSearch && matchesCity) 
            {
            photo.style.display = "";
        } else 
            {
            photo.style.display = "none";
        }
    });
}
photoSearch.addEventListener("input", filterPhotos);
photoCity.addEventListener("change", filterPhotos);
