
const articles = [

    {
        city: "Barcelona",
        title: "The Best Things to Do in Barcelona",
        description: "Discover Barcelona's famous architecture, museums, food and beautiful attractions.",
        url: "https://ticketshop.barcelona/?gad_source=1&gad_campaignid=2040087722&gbraid=0AAAAAD2o7EYCncwj-jWbOtfg2NfS9j22S&gclid=Cj0KCQiAwdDXBhDuARIsAFdLukmJ6Km_ls8Uc5YtXui1_mq-9sOSkdPaez7WoDm-XWkw2jXoOWWdDUMaAt9oEALw_wcB"
    },

    {
        city: "London",
        title: "Best Things to Do in London",
        description: "Explore London's famous landmarks, museums, entertainment and hidden gems.",
        url: "https://thattravel.co.uk/free-things-to-do-in-london/"
    },

    {
        city: "New York",
        title: "Things to Know Before Visiting New York City",
        description: "Learn about transportation, food, attractions and useful travel advice for NYC.",
        url: "https://theworldtravelguy.com/nyc-things-to-do/"
    },

    {
        city: "Paris",
        title: "Paris: What to Do and What to See",
        description: "Discover the Eiffel Tower, Louvre, Notre-Dame and other famous Paris attractions.",
        url: "https://www.dangerous-business.com/touristy-things-worth-doing-in-paris/"
    },

    {
        city: "Rome",
        title: "The 10 Best Things to Do in Rome",
        description: "Explore ancient Roman history, the Colosseum, Vatican City and Italian food.",
        url: "https://romesite.com/attractions.html?gad_source=1&gad_campaignid=1682249745&gbraid=0AAAAAD2o7EZKLKLvfouFViIFGO7GLofON&gclid=Cj0KCQiAwdDXBhDuARIsAFdLukna0oAUP4aZ8lxiRVconWjc6XufngwcU1KIebrJNRgX4t5w2iM4s1UaAv_-EALw_wcB"
    },

    {
        city: "Santorini",
        title: "11 Best Things to Do in Santorini",
        description: "Discover beautiful beaches, white villages, sunsets and unforgettable Greek island experiences.",
        url: "https://eatsleepbreathetravel.com/things-to-do-in-santorini-greece/"
    },

    {
        city: "Tokyo",
        title: "Everything You Need to Know for the Perfect Tokyo Trip",
        description: "Explore Japanese culture, traditional temples, modern attractions and travel tips.",
        url: "https://travelbabbo.com/what-to-do-in-tokyo/"
    }

];
articles.sort(function(a, b) {
    return a.city.localeCompare(b.city);
});
const blog = document.getElementById("blog-container");
articles.forEach(function(article, index) {
    const element = document.createElement("div");
    element.className = "col-lg-4 col-md-6 mb-4";
    element.innerHTML = `
        <div class="blog-box">
            <h5>${article.city}</h5>
            <h3>${article.title}</h3>
            <p>${article.description}</p>
            <a href="${article.url}" target="_blank" rel="noopener noreferrer"class="btn btn-primary">Read more</a>
        </div>
    `;
    blog.appendChild(element);
});
