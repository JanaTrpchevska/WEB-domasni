function readMore(id) 
{
    let details = document.getElementById(id);
    details.classList.toggle("show");
}
function buyTicket(name) {
    let answer = confirm("Would you like to buy a ticket for " + name +"? The ticket is valid for one week after purchase.");
    if (answer) {
        alert("You selected " + name + "! Continue to payment.");
    }
}
let search = document.getElementById("search");
let continent = document.getElementById("continent");
let city = document.getElementById("city");
let budget = document.getElementById("budget");
function filterActivities() {
    let activities = document.querySelectorAll(".activity");
    activities.forEach(function(activity) {
        let name = activity.textContent.toLowerCase();
        let searchValue = search.value.toLowerCase();
        let activityCity = activity.dataset.city;
        let activityContinent = activity.dataset.continent;
        let price = Number(activity.dataset.price);
        let matchesSearch = name.includes(searchValue);
        let matchesContinent =
            continent.value === "" ||
            continent.value === activityContinent;
        let matchesCity =
            city.value === "" || city.value === activityCity;
        let matchesBudget = true;
        if (budget.value === "free")
            {
            matchesBudget = price === 0;
        }
        else if (budget.value === "low") {
            matchesBudget = price > 0 && price < 30;
        }
        else if (budget.value === "medium") {
            matchesBudget = price >= 30 && price <= 70;
        }
        else if (budget.value === "high") 
            {
            matchesBudget = price > 70;
        }
        if (matchesSearch && matchesContinent && matchesCity && matchesBudget) 
            {
            activity.style.display = "";
        } else {
            activity.style.display = "none";
        }
    });
}
if (search) {
    search.addEventListener("input", filterActivities);
    continent.addEventListener("change", filterActivities);
    city.addEventListener("change", filterActivities);
    budget.addEventListener("change", filterActivities);
}
function bookHotel(button, hotelName) {
    let box = button.parentElement;
    let checkin = box.querySelector(".checkin").value;
    let checkout = box.querySelector(".checkout").value;
    let today = new Date();
    today.setHours(0, 0, 0, 0);
    let start = new Date(checkin + "T00:00:00");
    let end = new Date(checkout + "T00:00:00");
    if (!checkin || !checkout) {
        alert("Please select both dates.");
        return;
    }
    if (start < today || end <= start) 
        {
        alert("Please select valid dates.");
        return;
    }
    let payment = confirm("You are booking " + hotelName + "\nCheck-in: " + checkin +"\nCheck-out: " + checkout + 
        "\n\nThe hotel must be paid in full.\n\nDo you want to continue?");
    if (payment)
         {
        alert(
            "Your booking for " + hotelName + " was successful!\n\n" + "Full payment selected.\n" +"Check-in: " + checkin + "\nCheck-out: " + checkout
        );
        let transactions =
            Number(localStorage.getItem("transactions")) || 0;
        transactions++;
        localStorage.setItem("transactions", transactions);
        if (transactions % 3 === 0) {
            window.open("survey.html", "_blank");
        }
    } else {
        alert("Booking cancelled.");
    }
}
let hotelSearch = document.getElementById("hotelSearch");
if (hotelSearch) 
    {
    hotelSearch.addEventListener("input", function() 
    {
        let hotels = document.querySelectorAll(".hotel-box");
        hotels.forEach(function(hotel) 
        {
            let name = hotel.textContent.toLowerCase();
            if (name.includes(hotelSearch.value.toLowerCase())) 
                {
                    hotel.style.display = "flex";
                } else 
                    {
                    hotel.style.display = "none";
                }
        });
    });
}
