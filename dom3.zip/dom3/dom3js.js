
let drivers = [
    {
        name: "Lewis Hamilton",
        team: "Ferrari",
        speed: 96,
        weight: 75
    },
    {
        name: "Max Verstappen",
        team: "Red Bull",
        speed: 99,
        weight: 72
    },
    {
        name: "Charles Leclerc",
        team: "Ferrari",
        speed: 97,
        weight: 73
    },
    {
        name: "Lando Norris",
        team: "McLaren",
        speed: 98,
        weight: 70
    },
    {
        name: "Oscar Piastri",
        team: "McLaren",
        speed: 95,
        weight: 71
    },
    {
        name: "George Russell",
        team: "Mercedes",
        speed: 94,
        weight: 74
    },
    {
        name: "Fernando Alonso",
        team: "Aston Martin",
        speed: 92,
        weight: 76
    },
    {
        name: "Carlos Sainz",
        team: "Williams",
        speed: 95,
        weight: 74
    },
    {
        name: "Pierre Gasly",
        team: "Alpine",
        speed: 91,
        weight: 73
    },
    {
        name: "Yuki Tsunoda",
        team: "Racing Bulls",
        speed: 90,
        weight: 71
    }
];
drivers.forEach(function(driver, index) {
    driver.totalTime = 0;
    driver.lap = 0;
    driver.tire = index % 2 === 0 ? "Soft" : "Hard";
    driver.tireWear = 0;
    driver.pitDone = false;
    driver.pitLap = 4 + (index % 4);
    driver.retired = false;
    driver.status = "Активен";
});
function showDrivers() {
    let html = "<table border='1' cellpadding='8'>";
    html += "<tr>";
    html += "<th>Име</th>";
    html += "<th>Тим</th>";
    html += "<th>Брзина</th>";
    html += "<th>Тежина</th>";
    html += "<th>Гуми</th>";
    html += "</tr>";
    drivers.forEach(function(driver) {
        html += "<tr>";
        html += "<td>" + driver.name + "</td>";
        html += "<td>" + driver.team + "</td>";
        html += "<td>" + driver.speed + "</td>";
        html += "<td>" + driver.weight + "</td>";
        html += "<td>" + driver.tire + "</td>";
        html += "</tr>";
    });
    html += "</table>";
    document.getElementById("drivers").innerHTML = html;
}
function calculateLapTime(driver, safetyCar) {
    let time = 95;
    time += (100 - driver.speed) * 0.18;
    time += (driver.weight - 70) * 0.08;
    if (driver.tire === "Soft") {

        time -= 1.8;
        driver.tireWear += 0.35;
    } 
    else {
        time -= 0.8;
        driver.tireWear += 0.15;
    }
    time += driver.tireWear;
    time += Math.random() * 0.8;
    if (safetyCar) {
        time += 2;
    }
    return time;
}
function startRace() {
    document.getElementById("winner").innerHTML = "";
    document.getElementById("history").innerHTML = "";
    document.getElementById("results").innerHTML = "";
    let historyHTML = "";
    historyHTML += "<h3>Почеток на трката</h3>";
    historyHTML += "<table border='1' cellpadding='6'>";
    historyHTML += "<tr>";
    historyHTML += "<th>Возач</th>";
    historyHTML += "<th>Почетен статус</th>";
    historyHTML += "</tr>";
    drivers.forEach(function(driver) {
        historyHTML += "<tr>";
        historyHTML += "<td>" + driver.name + "</td>";
        historyHTML += "<td>Активен</td>";
        historyHTML += "</tr>";
    });
    historyHTML += "</table>";
    for (let lap = 1; lap <= 10; lap++) {
        let safetyCar = Math.random() < 0.12;
        historyHTML += "<h3>Круг " + lap + "</h3>";
        if (safetyCar) {
            historyHTML += "<p>SAFETY CAR! На патеката има безбедносно возило.</p>";
        }
        historyHTML += "<table border='1' cellpadding='6'>";
        historyHTML += "<tr>";
        historyHTML += "<th>Возач</th>";
        historyHTML += "<th>Статус на почеток</th>";
        historyHTML += "<th>Настан</th>";
        historyHTML += "<th>Гуми</th>";
        historyHTML += "<th>Вкупно време</th>";
        historyHTML += "<th>Статус на крај</th>";
        historyHTML += "</tr>";
        drivers.forEach(function(driver) {
            let startStatus = driver.status;
            let event = "-";
            let eventClass = "";
            if (driver.retired) {

                historyHTML += "<tr>";
                historyHTML += "<td>" + driver.name + "</td>";
                historyHTML += "<td>Излезен</td>";
                historyHTML += "<td>-</td>";
                historyHTML += "<td>-</td>";
                historyHTML += "<td>" + driver.totalTime.toFixed(2) + " s</td>";
                historyHTML += "<td>Излезен</td>";
                historyHTML += "</tr>";
                return;
            }
            driver.lap = lap;
            driver.status = "Активен";
            if (!driver.pitDone && lap === driver.pitLap) {
                driver.status = "Во пит-стоп";
                event = "Пит-стоп: промена на гуми";
                eventClass += " pit-event";
                if (driver.tire === "Soft") 
                {
                    driver.tire = "Hard";
                } else {
                    driver.tire = "Soft";
                }
                driver.tireWear = 0;
                driver.totalTime += 22;
                driver.pitDone = true;
            }
            let lapTime = calculateLapTime(driver, safetyCar);
            driver.totalTime += lapTime;
            let spun = Math.random() < 0.04;
            if (spun) {
                driver.totalTime += 7;
                event += " Возачот се извртел (+7s)";
                eventClass += " spun-event";
            }
            if (driver.pitDone && lap >= 5 && Math.random() < 0.008) {
                driver.retired = true;
                driver.status = "Излезен";
                event += " Возачот ја напушти трката";
            }
            if (event === "-") {
                event = "Нема посебен настан";
            }
            historyHTML += "<tr>";
            historyHTML += "<td>" + driver.name + "</td>";
            historyHTML += "<td>" + startStatus + "</td>";
          historyHTML += "<td class='" + eventClass + "'>" + event + "</td>";
            historyHTML += "<td>" + driver.tire + "</td>";
            historyHTML += "<td>" + driver.totalTime.toFixed(2) + " s</td>";
            historyHTML += "<td>" + driver.status + "</td>";
            historyHTML += "</tr>";
        });
        historyHTML += "</table>";
    }
    document.getElementById("history").innerHTML = historyHTML;
    let ranking = drivers.slice().sort(function(a, b) {
        if (a.retired && !b.retired) return 1;
        if (!a.retired && b.retired) return -1;
        return a.totalTime - b.totalTime;
    });
    let resultHTML = "<table border='1' cellpadding='8'>";
    resultHTML += "<tr>";
    resultHTML += "<th>Позиција</th>";
    resultHTML += "<th>Возач</th>";
    resultHTML += "<th>Тим</th>";
    resultHTML += "<th>Вкупно време</th>";
    resultHTML += "<th>Статус</th>";
    resultHTML += "</tr>";
    ranking.forEach(function(driver, index) {
        resultHTML += "<tr>";
        resultHTML += "<td>" + (index + 1) + "</td>";
        resultHTML += "<td>" + driver.name + "</td>";
        resultHTML += "<td>" + driver.team + "</td>";
        resultHTML += "<td>" + driver.totalTime.toFixed(2) + " s</td>";
        resultHTML += "<td>" + driver.status + "</td>";
        resultHTML += "</tr>";
    });
    resultHTML += "</table>";
    document.getElementById("results").innerHTML = resultHTML;

let podium = ranking.filter(function(driver) {

    return !driver.retired && driver.lap === 10;

});

let first = podium[0];
let second = podium[1];
let third = podium[2];
let winnerHTML = "";
if (first) {
    winnerHTML += "<div class='podium'>";
    winnerHTML += "<div class='second-place'>";
    if (second) {
        winnerHTML += "<h2>2. МЕСТО</h2>";

        winnerHTML += "<h3>" + second.name.toUpperCase() + "</h3>";

        winnerHTML += "<p>" + second.team + "</p>";
        winnerHTML += "<p>Брзина: " + second.speed + "</p>";
    }
    winnerHTML += "</div>";
    winnerHTML += "<div class='first-place'>";
    winnerHTML += "<h1>1. МЕСТО - ПОБЕДНИК</h1>";
    winnerHTML += "<h2>" + first.name.toUpperCase() + "</h2>";
    winnerHTML += "<h3>" + first.team + "</h3>";
    winnerHTML += "<p>Брзина: " + first.speed + "</p>";
    winnerHTML += "<p>Вкупно време: " + first.totalTime.toFixed(2) + " секунди</p>";
    winnerHTML += "</div>";
    winnerHTML += "<div class='third-place'>";
    if (third) {
        winnerHTML += "<h2>3. МЕСТО</h2>";
        winnerHTML += "<h3>" + third.name.toUpperCase() + "</h3>";
        winnerHTML += "<p>" + third.team + "</p>";
        winnerHTML += "<p>Брзина: " + third.speed + "</p>";
    }
    winnerHTML += "</div>";
    winnerHTML += "</div>";
} else {
    winnerHTML = "<h2>Нема возач што ја заврши трката!</h2>";
}
document.getElementById("winner").innerHTML = winnerHTML;
}
function showSpeedRanking() {
    let speedRanking = drivers.slice().sort(function(a, b) {
        return b.speed - a.speed;
    });
    let html = "<table class='speed-table'>";
    html += "<tr>";
    html += "<th>Место</th>";
    html += "<th>Возач</th>";
    html += "<th>Тим</th>";
    html += "<th>Брзина</th>";
    html += "</tr>";
    speedRanking.forEach(function(driver, index) {
        html += "<tr>";
        html += "<td>" + (index + 1) + "</td>";
        html += "<td>" + driver.name + "</td>";
        html += "<td>" + driver.team + "</td>";
        html += "<td>" + driver.speed + "</td>";
        html += "</tr>";
    });
    html += "</table>";
    document.getElementById("speedRanking").innerHTML = html;
}
showDrivers();
